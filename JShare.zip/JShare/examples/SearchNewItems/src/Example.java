import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.independentsoft.share.KeyValue;
import com.independentsoft.share.SearchQuery;
import com.independentsoft.share.SearchResult;
import com.independentsoft.share.SearchResultPropertyName;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;
import com.independentsoft.share.SimpleDataRow;
import com.independentsoft.share.SimpleDataTable;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
    		Calendar calendar = Calendar.getInstance();
    		calendar.set(Calendar.HOUR_OF_DAY, 0);
    		calendar.set(Calendar.MINUTE, 0);
    		calendar.set(Calendar.SECOND, 0);
    		calendar.set(Calendar.MILLISECOND, 0);
    		
    		Date today = calendar.getTime();
    		
    	     //Query restriction created with KQL (Keyword Query Language). Has only day precision when searching date/time properties
    		com.independentsoft.share.kql.IsGreaterThan restriction1 = new com.independentsoft.share.kql.IsGreaterThan(SearchResultPropertyName.CREATED_TIME, today);

            //Query restriction created with FQL (Fast Query Language). Has second/millisecond precision when searching date/time properties
    		//com.independentsoft.share.fql.IsGreaterThan restriction1 = new com.independentsoft.share.fql.IsGreaterThan(SearchResultPropertyName.CREATED_TIME, today);

            SearchQuery query = new SearchQuery(restriction1);
            query.getSelectProperties().add(SearchResultPropertyName.TITLE);
            query.getSelectProperties().add(SearchResultPropertyName.PATH);
            query.getSelectProperties().add(SearchResultPropertyName.CREATED_TIME);

            SearchResult searchResult = service.search(query);

            SimpleDataTable table = searchResult.getPrimaryQueryResult().getRelevantResult().getTable();

            for (SimpleDataRow row : table.getRows())
            {
                for (KeyValue cell : row.getCells())
                {
                    if (cell.getKey().equals(SearchResultPropertyName.TITLE))
                    {
                    	System.out.println("Title: " + cell.getValue());
                    }
                    else if (cell.getKey().equals(SearchResultPropertyName.PATH))
                    {
                    	System.out.println("Path: " +  cell.getValue());
                    }
                    else if (cell.getKey().equals(SearchResultPropertyName.CREATED_TIME))
                    {
                        Date localTime = toLocalTime(cell.getValue());
                        System.out.println("CreatedTime: " + localTime);
                    }
                }
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
    	catch (ParseException e) 
        {
			e.printStackTrace();
		}
	}
    
    static Date toLocalTime(String utcTime) throws ParseException
    {
        if (utcTime != null && utcTime.length() > 0)
        {
            String format = "yyyy-MM-dd'T'HH:mm:ss.ssssss'Z'";

            DateFormat dateFormat = new SimpleDateFormat(format, Locale.US);
            Calendar utcCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));

            dateFormat.setCalendar(utcCalendar);

            return dateFormat.parse(utcTime);
        }
        else
        {
            return null;
        }
    }
}
