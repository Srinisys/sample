import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            boolean publishSuccess = service.publish("/Shared Documents/Test.docx", "Check-in comment for the publish.");

            System.out.println("Publish success = " + publishSuccess);

            boolean approveSuccess = service.approve("/Shared Documents/Test.docx", "Check-in comment for the approval.");

            System.out.println("Approve success = " + approveSuccess);
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
