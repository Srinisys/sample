import java.util.List;

import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            List<com.independentsoft.share.List> lists = service.getLists();

            for (int i = 0; i < lists.size(); i++)
            {
            	System.out.println("Id: " + lists.get(i).getId());
            	System.out.println("Title: " + lists.get(i).getTitle());
            	System.out.println("Description: " + lists.get(i).getDescription());
            	System.out.println("---------------------------------------------");
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
