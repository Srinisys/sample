import com.independentsoft.share.File;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            File file = service.getFile("/Shared Documents/Test.docx");

            System.out.println("Name: " + file.getName());
            System.out.println("Title: " + file.getTitle());
            System.out.println("MajorVersion: " + file.getMajorVersion());
            System.out.println("MinorVersion: " + file.getMinorVersion());
            System.out.println("Length: " + file.getLength());
            System.out.println("LastModifiedTime: " + file.getLastModifiedTime());
            System.out.println("CheckOutType: " + file.getCheckOutType());
            System.out.println("CheckInComment: " + file.getCheckInComment());

        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
