import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            InputStream inputStream = service.getFileStream("/Shared Documents/Test.docx");

            FileOutputStream outputStream = new FileOutputStream("e:\\Test.docx");
	    	
	        try
	        {
                byte[] buffer = new byte[8192];
                int len = 0;

                while ((len = inputStream.read(buffer, 0, buffer.length)) > 0)
                {
                    outputStream.write(buffer, 0, len);
                }
	        }
	    	finally
	    	{   		
	    		if(inputStream != null)
	    		{
	    			inputStream.close();
	    		}
	    		
	    		if(outputStream != null)
	    		{
	    			outputStream.close();
	    		}
	    	}
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
        catch (IOException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	
        	ex.printStackTrace();
        }
	}
}
