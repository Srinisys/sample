import java.util.List;

import com.independentsoft.share.Change;
import com.independentsoft.share.ChangeItem;
import com.independentsoft.share.ChangeQuery;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		 
            ChangeQuery query = new ChangeQuery();
            query.setAdd(true);
            query.setUpdate(true);
            query.setItem(true);

            List<Change> initialChanges = service.getChanges(query);

            for (Change change : initialChanges)
            {
                if (change instanceof ChangeItem)
                {
                    ChangeItem changeItem = (ChangeItem)change;

                    System.out.println(changeItem.getItemId());
                    System.out.println(changeItem.getTime());
                    System.out.println(changeItem.getType());
                    System.out.println("-----------------------------------------------");
                }
            }

            if(initialChanges.size() > 0)
            {
                //set ChangeTokenStart to get only changes after the last change occurred 
                query.setChangeTokenStart(initialChanges.get(initialChanges.size() - 1).getToken());
            }

            while (true)
            {
                List<Change> changes = service.getChanges(query);

                if (changes.size() > 0)
                {
                	System.out.println("NEW CHANGES ....");

                    for (int i = 0; i < changes.size(); i++)
                    {
                        if (changes.get(i) instanceof ChangeItem)
                        {
                            ChangeItem changeItem = (ChangeItem)changes.get(i);

                            System.out.println("Change type: " + changeItem.getType());
                            System.out.println(changeItem.getItemId());
                            System.out.println(changeItem.getTime());
                            System.out.println("-----------------------------------------------");
                        }
                    }

                    //set ChangeTokenStart to get only changes after the last change occurred 
                    query.setChangeTokenStart(changes.get(changes.size() - 1).getToken());
                }
                else
                {
                	System.out.println("NO NEW CHANGES ....");
                }

                Thread.currentThread().join(10000); //wait 10 seconds
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        } 
    	catch (InterruptedException e) 
        {
			e.printStackTrace();
		}
	}
}
