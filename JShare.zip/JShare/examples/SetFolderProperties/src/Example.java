import com.independentsoft.share.FieldValue;
import com.independentsoft.share.FilePropertyName;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            FieldValue fieldValue1 = new FieldValue("MyField", "NewValue");
            FieldValue fieldValue2 = new FieldValue("Title", "MyNewTitle");
            
            service.setFolderFieldValue("/Shared Documents/MyFolder", fieldValue1);
            service.setFolderFieldValue("/Shared Documents/MyFolder", fieldValue2);
            
            //Single request to set many properties (field values).
            
            java.util.List<FieldValue> list = new java.util.ArrayList<FieldValue>();
            list.add(fieldValue1);
            list.add(fieldValue2);
                       
            service.setFolderFieldValues("/Shared Documents/MyFolder", list);
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
