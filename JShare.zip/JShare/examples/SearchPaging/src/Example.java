import com.independentsoft.share.KeyValue;
import com.independentsoft.share.SearchQuery;
import com.independentsoft.share.SearchResult;
import com.independentsoft.share.SearchResultPropertyName;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;
import com.independentsoft.share.SimpleDataRow;
import com.independentsoft.share.SimpleDataTable;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		   		
    		com.independentsoft.share.kql.Contains restriction1 = new com.independentsoft.share.kql.Contains(SearchResultPropertyName.PATH, "https://independentsoft.sharepoint.com/Shared Documents/");

            SearchQuery query = new SearchQuery(restriction1);
            query.getSelectProperties().add(SearchResultPropertyName.TITLE);
            query.getSelectProperties().add(SearchResultPropertyName.PATH);
            query.setRowLimit(100);

            while(true)
            {
	            SearchResult searchResult = service.search(query);
	
	            SimpleDataTable table = searchResult.getPrimaryQueryResult().getRelevantResult().getTable();
	
	            for (SimpleDataRow row : table.getRows())
	            {
	                for (KeyValue cell : row.getCells())
	                {
	                    if (cell.getKey().equals(SearchResultPropertyName.TITLE))
	                    {
	                    	System.out.println("Title: " + cell.getValue());
	                    }
	                    else if (cell.getKey().equals(SearchResultPropertyName.PATH))
	                    {
	                    	System.out.println("Path: " +  cell.getValue());
	                    }
	                }
	            }
	            
               query.setStartRow(query.getStartRow() + table.getRows().size());

               if (query.getStartRow() >= searchResult.getPrimaryQueryResult().getRelevantResult().getTotalRows())
               {
                   break;
               }
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
