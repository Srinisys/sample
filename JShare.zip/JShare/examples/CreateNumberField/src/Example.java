import com.independentsoft.share.Field;
import com.independentsoft.share.FieldType;
import com.independentsoft.share.Locale;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            Field numberField = new Field();
            numberField.setType(FieldType.NUMBER);
            numberField.setTitle("Length");
            numberField.setDescription("Length column description");
            numberField.setDefaultValue("0");
            numberField.setMinimumValue(0);
            numberField.setMaximumValue(1000);

            Field createdNumberField = service.createField(numberField);
			
		    System.out.println("Id: " + createdNumberField.getId());
			System.out.println("Title: " + createdNumberField.getTitle());
			System.out.println("InternalName: " + createdNumberField.getInternalName());
			System.out.println("------------------------------------------------");
			
            Field currencyField = new Field();
            currencyField.setType(FieldType.CURRENCY);
            currencyField.setTitle("Salary");
            currencyField.setDescription("Worker salary");
            currencyField.setCurrencyLocale(Locale.ENGLISH_UNITED_STATES);
		
			Field createdCurrencyField = service.createField(currencyField);
			
		    System.out.println("Id: " + createdCurrencyField.getId());
			System.out.println("Title: " + createdCurrencyField.getTitle());
			System.out.println("InternalName: " + createdCurrencyField.getInternalName());          
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
