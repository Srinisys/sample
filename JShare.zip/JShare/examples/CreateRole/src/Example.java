import com.independentsoft.share.BasePermission;
import com.independentsoft.share.Role;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	            
            Role role1 = new Role();
            role1.setName("TestFullAccess");
            role1.setDescription("Full access");
            role1.getBasePermissions().add(BasePermission.ALL_PERMISSIONS);

            Role role2 = new Role();
            role2.setName("TestGuestAccess");
            role2.setDescription("Guest permissions");
            role2.getBasePermissions().add(BasePermission.VIEW_FORM_PAGES);
            role2.getBasePermissions().add(BasePermission.VIEW_LIST_ITEMS);
            role2.getBasePermissions().add(BasePermission.VIEW_PAGES);
            role2.getBasePermissions().add(BasePermission.BROWSE_DIRECTORIES);

            Role createdRole1 = service.createRole(role1);
            Role createdRole2 = service.createRole(role2);

            System.out.println("Role 1 Id: " + createdRole1.getId());
            System.out.println("Role 2 Id: " + createdRole2.getId());
            
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
