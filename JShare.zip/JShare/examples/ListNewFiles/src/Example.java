import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.independentsoft.share.File;
import com.independentsoft.share.FilePropertyName;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;
import com.independentsoft.share.queryoptions.Filter;
import com.independentsoft.share.queryoptions.IQueryOption;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            Date queryTime = new Date(); //now
            Thread.currentThread().join(30000); //wait 30 seconds

            while (true)
            {
                com.independentsoft.share.queryoptions.IsGreaterThan restriction = new com.independentsoft.share.queryoptions.IsGreaterThan(FilePropertyName.CREATED_TIME, queryTime);

                Filter filter = new Filter(restriction);

                List<IQueryOption> queryOption = new ArrayList<IQueryOption>();
                queryOption.add(filter);

                List<File> files = service.getFiles("/Shared Documents", queryOption);

                queryTime = new Date(); //now

                if (files.size() > 0)
                {
                	System.out.println("NEW FILES ....");

                    for (int i = 0; i < files.size(); i++)
                    {
                    	System.out.println("Name: " + files.get(i).getName());
                        System.out.println("Path: " + files.get(i).getServerRelativeUrl());
                        System.out.println("Length: " + files.get(i).getLength());
                        System.out.println("CreatedTime: " + files.get(i).getCreatedTime());
                        System.out.println("LastModifiedTime: " + files.get(i).getLastModifiedTime());
                        System.out.println("---------------------------------------------");
                    }
                }
                else
                {
                	System.out.println("NO NEW FILES ...");
                }

                Thread.currentThread().join(30000); //wait 30 seconds
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
    	catch (InterruptedException e) 
        {
			e.printStackTrace();
		}
	}
}
