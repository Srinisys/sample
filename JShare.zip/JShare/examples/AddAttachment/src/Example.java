import com.independentsoft.share.Attachment;
import com.independentsoft.share.Service;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            com.independentsoft.share.List myList = service.getListByTitle("MyList123");
                        
            java.io.File file = new java.io.File("e:\\test.txt");
                       
            Attachment attachment = service.createListItemAttachment(myList.getId(), 3, file);
            
            System.out.println("Attachment url = " + attachment.getServerRelativeUrl());
        } 
        catch (Exception ex)
        {
        	System.out.println("Error: " + ex.getMessage());

        	ex.printStackTrace();
        }
	}
}
