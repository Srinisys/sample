import java.util.List;

import com.independentsoft.share.FieldValue;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            List<FieldValue> values = service.getFieldValues("dbf4c193-34ee-4719-901e-4f2aa290883a", 1);

            for (int i = 0; i < values.size(); i++)
            {
            	System.out.println(values.get(i).getName() + ": " + values.get(i).getValue());
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
