import java.util.List;

import com.independentsoft.share.File;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            List<File> files = service.getFiles("/");

            for (int i = 0; i < files.size(); i++)
            {
            	System.out.println("Name: " + files.get(i).getName());                    
            	System.out.println("Path: " + files.get(i).getServerRelativeUrl());
            	System.out.println("Length: " + files.get(i).getLength());
            	System.out.println("LastModifiedTime: " + files.get(i).getLastModifiedTime());
            	System.out.println("---------------------------------------------");
            }

            List<File> files2 = service.getFiles("/Shared Documents");

            for (int i = 0; i < files2.size(); i++)
            {
            	System.out.println("Name: " + files2.get(i).getName());                    
            	System.out.println("Path: " + files2.get(i).getServerRelativeUrl());
            	System.out.println("Length: " + files2.get(i).getLength());
            	System.out.println("LastModifiedTime: " + files2.get(i).getLastModifiedTime());
            	System.out.println("---------------------------------------------");
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
