import com.independentsoft.share.Field;
import com.independentsoft.share.FieldType;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
			Field textField = new Field();
			textField.setType(FieldType.TEXT);
			textField.setTitle("Project Name");
			textField.setMaximumLength(22);
			
			Field createdTextField = service.createField(textField);
			
		    System.out.println("Id: " + createdTextField.getId());
			System.out.println("Title: " + createdTextField.getTitle());
			System.out.println("InternalName: " + createdTextField.getInternalName());
			System.out.println("------------------------------------------------");
			
			Field noteField = new Field();
			noteField.setType(FieldType.NOTE);
			noteField.setTitle("Comment");
			noteField.setNumberOfLines(10);
			
			Field createdNoteField = service.createField(noteField);
			
		    System.out.println("Id: " + createdNoteField.getId());
			System.out.println("Title: " + createdNoteField.getTitle());
			System.out.println("InternalName: " + createdNoteField.getInternalName());          
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
