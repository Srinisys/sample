import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");

            boolean deleteSuccess1 = service.deleteFileVersion("/Shared Documents/Test.docx", "1.0");

            System.out.println("The version with label 1.0 deleted: " + deleteSuccess1);

            boolean deleteSuccess2 = service.deleteAllFileVersions("/Shared Documents/Test2.docx");

            System.out.println("All versions deleted: " + deleteSuccess2);
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
