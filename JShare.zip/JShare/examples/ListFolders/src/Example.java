import java.util.List;

import com.independentsoft.share.Folder;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            List<Folder> folders = service.getFolders("/");

            for (int i = 0; i < folders.size(); i++)
            {
            	System.out.println("Name: " + folders.get(i).getName());                    
            	System.out.println("Path: " + folders.get(i).getServerRelativeUrl());
            	System.out.println("ItemCount: " + folders.get(i).getItemCount());
            	System.out.println("---------------------------------------------");
            }

            List<Folder> folders2 = service.getFolders("/Shared Documents");

            for (int i = 0; i < folders2.size(); i++)
            {
            	System.out.println("Name: " + folders2.get(i).getName());                    
            	System.out.println("Path: " + folders2.get(i).getServerRelativeUrl());
            	System.out.println("ItemCount: " + folders2.get(i).getItemCount());
            	System.out.println("---------------------------------------------");
            }

        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
