import com.independentsoft.share.Field;
import com.independentsoft.share.FieldType;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            Field choiceField = new Field();
            choiceField.setType(FieldType.CHOICE);
            choiceField.setTitle("Gender");
            choiceField.getChoices().add("Male");
            choiceField.getChoices().add("Female");

            Field createdNumberField = service.createField(choiceField);
			
		    System.out.println("Id: " + createdNumberField.getId());
			System.out.println("Title: " + createdNumberField.getTitle());
			System.out.println("InternalName: " + createdNumberField.getInternalName());      
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
