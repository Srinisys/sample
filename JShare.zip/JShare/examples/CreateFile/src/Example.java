import java.io.UnsupportedEncodingException;

import com.independentsoft.share.File;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
	         String text = "Simple text file content";
             byte[] buffer = text.getBytes("UTF-8");

             File file = service.createFile("/Shared Documents/MyFile.txt", buffer);
             
 	         System.out.println("ServerRelativeUrl: " + file.getServerRelativeUrl());
 	         System.out.println("UniqueId: " + file.getUniqueId());
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
        catch (UnsupportedEncodingException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	
        	ex.printStackTrace();
        }
	}
}
