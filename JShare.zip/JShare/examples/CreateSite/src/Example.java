import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;
import com.independentsoft.share.Site;
import com.independentsoft.share.SiteCreationInfo;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            SiteCreationInfo siteInfo = new SiteCreationInfo();
            siteInfo.setTitle("Social Media");
            siteInfo.setUrl("Social");
            siteInfo.setWebTemplate("MPS#3");
            siteInfo.setSamePermissionsAsParentSite(true);

            Site createdSite = service.createSite(siteInfo);

            System.out.println("MasterUrl: " + createdSite.getMasterUrl());
            System.out.println("ServerRelativeUrl: " + createdSite.getServerRelativeUrl());            
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
