import java.util.List;

import com.independentsoft.share.Folder;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
            Service service = new Service("https://independentsoft-my.sharepoint.com/personal/info_independentsoft_onmicrosoft_com", "info@independentsoft.onmicrosoft.com", "password");
	
            List<Folder> folders = service.getFolders("/personal/info_independentsoft_onmicrosoft_com");

            for (int i = 0; i < folders.size(); i++)
            {
            	System.out.println("Name: " + folders.get(i).getName());                    
            	System.out.println("Path: " + folders.get(i).getServerRelativeUrl());
            	System.out.println("ItemCount: " + folders.get(i).getItemCount());
            	System.out.println("---------------------------------------------");
            }
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
