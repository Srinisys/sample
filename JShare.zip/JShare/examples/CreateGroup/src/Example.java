import com.independentsoft.share.Group;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            Group group = new Group();
            group.setTitle("Test");
            group.setDescription("Group description");
            group.allowOnlyMembersViewMembership(true);
            group.allowRequestToJoinLeave(true);

            Group createdGroup = service.createGroup(group);

            System.out.println("Id: " + createdGroup.getId());
            System.out.println("LoginName: " + createdGroup.getLoginName());
            
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
