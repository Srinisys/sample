import com.independentsoft.share.List;
import com.independentsoft.share.ListTemplateType;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            List list = new List();
            list.setTitle("Test");
            list.setBaseTemplate(ListTemplateType.GENERIC_LIST);
            list.setContentTypesEnabled(true);
            list.setDescription("My list description");

            List createdList = service.createList(list);

            System.out.println("Id: " + createdList.getId());
            System.out.println("EntityTypeName: " + createdList.getEntityTypeName());
            System.out.println("ListItemEntityTypeFullName: " + createdList.getListItemEntityTypeFullName());           
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
