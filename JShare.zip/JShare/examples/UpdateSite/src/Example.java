import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;
import com.independentsoft.share.Site;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		 Service service = new Service("https://independentsoft.sharepoint.com/Social", "username", "password");
    		
    		 Site site = new Site();
             site.setTitle("Social Media New Site");
             site.setDescription("New Description");
             site.enableMinimalDownload(true);

             service.updateSite(site);           
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
