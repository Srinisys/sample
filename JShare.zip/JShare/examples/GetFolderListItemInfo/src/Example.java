import com.independentsoft.share.ListItemInfo;
import com.independentsoft.share.Service;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            ListItemInfo listItemInfo = service.getFolderListItemInfo("/Shared Documents/MyFolder");
                                    
            System.out.println("List Id of the folder = " + listItemInfo.getListId());
            System.out.println("Item Id of the folder = " + listItemInfo.getItemId());
        } 
        catch (Exception ex)
        {
        	System.out.println("Error: " + ex.getMessage());

        	ex.printStackTrace();
        }
	}
}
