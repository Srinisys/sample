import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
            //delete file
            service.deleteFile("/Shared Documents/Test.docx");

            //move file to the Recycle Bin
            String recycledFileId = service.recycleFile("/Shared Documents/Test2.docx");

            System.out.println("recycledFileId = " + recycledFileId);
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
