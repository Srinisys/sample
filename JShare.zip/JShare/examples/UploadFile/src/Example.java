import java.io.FileInputStream;
import java.io.IOException;

import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
	
	    	FileInputStream fileStream = null;
	    	
	        try
	        {
	        	fileStream = new FileInputStream("e:\\Test.docx");

	        	service.createFile("/Shared Documents/Test.docx", fileStream);
	        }
	    	finally
	    	{
	    		if(fileStream != null)
	    		{
	    			fileStream.close();
	    		}
	    	}
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
        catch (IOException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	
        	ex.printStackTrace();
        }
	}
}
