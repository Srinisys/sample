import com.independentsoft.share.DateTimeFieldFormatType;
import com.independentsoft.share.Field;
import com.independentsoft.share.FieldType;
import com.independentsoft.share.Service;
import com.independentsoft.share.ServiceException;

public class Example {

    public static void main(String[] args)
    {
    	try
    	{
    		Service service = new Service("https://independentsoft.sharepoint.com", "username", "password");
    		
            Field dateTimeField = new Field();
            dateTimeField.setType(FieldType.DATE_TIME);
            dateTimeField.setTitle("Birthday");
            dateTimeField.setDescription("Column/Field description");
            dateTimeField.setDateTimeDisplayFormat(DateTimeFieldFormatType.DATE);

            Field createdNumberField = service.createField(dateTimeField);
			
		    System.out.println("Id: " + createdNumberField.getId());
			System.out.println("Title: " + createdNumberField.getTitle());
			System.out.println("InternalName: " + createdNumberField.getInternalName());      
        } 
        catch (ServiceException ex)
        {
        	System.out.println("Error: " + ex.getMessage());
        	System.out.println("Error: " + ex.getErrorCode());
        	System.out.println("Error: " + ex.getErrorString());
        	System.out.println("Error: " + ex.getRequestUrl());

        	ex.printStackTrace();
        }
	}
}
